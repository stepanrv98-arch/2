package dev.camsys;

import org.bukkit.block.Block;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/** Хранилище мониторов и камер (файл data.yml). */
public final class CamData {

    public static final class Mon {
        public UUID id;
        public String world;
        public int x, y, z;
    }

    public static final class Cam {
        public UUID id;
        public String world;
        public int x, y, z;
        public float yaw;
        public UUID monitor; // null - не привязана
        public int slot;     // 1..10
    }

    public static final int MAX_CAMS = 10;

    public final Map<UUID, Mon> monitors = new LinkedHashMap<>();
    public final Map<UUID, Cam> cameras = new LinkedHashMap<>();
    public int mapId = -1;
    private final File file;

    public CamData(File file) {
        this.file = file;
    }

    public void load() {
        monitors.clear();
        cameras.clear();
        if (!file.exists()) return;
        YamlConfiguration y = YamlConfiguration.loadConfiguration(file);
        mapId = y.getInt("mapId", -1);

        ConfigurationSection ms = y.getConfigurationSection("monitors");
        if (ms != null) {
            for (String k : ms.getKeys(false)) {
                ConfigurationSection s = ms.getConfigurationSection(k);
                if (s == null) continue;
                Mon m = new Mon();
                m.id = UUID.fromString(k);
                m.world = s.getString("world", "world");
                m.x = s.getInt("x");
                m.y = s.getInt("y");
                m.z = s.getInt("z");
                monitors.put(m.id, m);
            }
        }
        ConfigurationSection cs = y.getConfigurationSection("cameras");
        if (cs != null) {
            for (String k : cs.getKeys(false)) {
                ConfigurationSection s = cs.getConfigurationSection(k);
                if (s == null) continue;
                Cam c = new Cam();
                c.id = UUID.fromString(k);
                c.world = s.getString("world", "world");
                c.x = s.getInt("x");
                c.y = s.getInt("y");
                c.z = s.getInt("z");
                c.yaw = (float) s.getDouble("yaw");
                String mon = s.getString("monitor", "");
                c.monitor = (mon == null || mon.isEmpty()) ? null : UUID.fromString(mon);
                c.slot = s.getInt("slot");
                cameras.put(c.id, c);
            }
        }
    }

    public void save() {
        YamlConfiguration y = new YamlConfiguration();
        y.set("mapId", mapId);
        for (Mon m : monitors.values()) {
            String p = "monitors." + m.id;
            y.set(p + ".world", m.world);
            y.set(p + ".x", m.x);
            y.set(p + ".y", m.y);
            y.set(p + ".z", m.z);
        }
        for (Cam c : cameras.values()) {
            String p = "cameras." + c.id;
            y.set(p + ".world", c.world);
            y.set(p + ".x", c.x);
            y.set(p + ".y", c.y);
            y.set(p + ".z", c.z);
            y.set(p + ".yaw", (double) c.yaw);
            y.set(p + ".monitor", c.monitor == null ? "" : c.monitor.toString());
            y.set(p + ".slot", c.slot);
        }
        try {
            y.save(file);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public Mon monitorAt(Block b) {
        for (Mon m : monitors.values()) {
            if (m.x == b.getX() && m.y == b.getY() && m.z == b.getZ() && m.world.equals(b.getWorld().getName())) return m;
        }
        return null;
    }

    public Cam cameraAt(Block b) {
        for (Cam c : cameras.values()) {
            if (c.x == b.getX() && c.y == b.getY() && c.z == b.getZ() && c.world.equals(b.getWorld().getName())) return c;
        }
        return null;
    }

    public boolean isRegistered(Block b) {
        return monitorAt(b) != null || cameraAt(b) != null;
    }

    /** Камеры монитора по порядку слотов. */
    public List<Cam> camsOf(UUID monitor) {
        List<Cam> out = new ArrayList<>();
        for (Cam c : cameras.values()) {
            if (monitor.equals(c.monitor)) out.add(c);
        }
        out.sort(Comparator.comparingInt(c -> c.slot));
        return out;
    }

    /** Свободный слот 1..10 или -1, если все заняты. */
    public int freeSlot(UUID monitor) {
        boolean[] used = new boolean[MAX_CAMS + 1];
        for (Cam c : camsOf(monitor)) {
            if (c.slot >= 1 && c.slot <= MAX_CAMS) used[c.slot] = true;
        }
        for (int i = 1; i <= MAX_CAMS; i++) {
            if (!used[i]) return i;
        }
        return -1;
    }
}

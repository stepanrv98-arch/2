package dev.camsys;

import com.destroystokyo.paper.profile.PlayerProfile;
import com.destroystokyo.paper.profile.ProfileProperty;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.SkullMeta;
import org.bukkit.inventory.meta.components.EquippableComponent;
import org.bukkit.persistence.PersistentDataType;

import java.util.List;
import java.util.UUID;

public final class Items {

    public static NamespacedKey TYPE;
    public static String monitorTexture = "";

    private static final String CAMERA_TEXTURE =
            "eyJ0ZXh0dXJlcyI6eyJTS0lOIjp7InVybCI6Imh0dHA6Ly90ZXh0dXJlcy5taW5lY3JhZnQubmV0L3RleHR1cmUvMTQ0MjJhODJjODk5YTljMTQ1NDM4NGQzMmNjNTRjNGFlN2ExYzRkNzI0MzBlNmU0NDZkNTNiOGIzODVlMzMwIn19fQ==";

    private Items() {}

    private static Component plain(Component c) {
        return c.decoration(TextDecoration.ITALIC, false);
    }

    private static ItemStack head(String type, String texture, Component name, List<Component> lore) {
        ItemStack it = new ItemStack(Material.PLAYER_HEAD);
        SkullMeta m = (SkullMeta) it.getItemMeta();
        if (texture != null && !texture.isEmpty()) {
            PlayerProfile pp = Bukkit.createProfile(UUID.nameUUIDFromBytes(("camsys-" + type).getBytes()), null);
            pp.setProperty(new ProfileProperty("textures", texture));
            m.setPlayerProfile(pp);
        }
        m.displayName(name);
        if (lore != null) m.lore(lore);
        m.getPersistentDataContainer().set(TYPE, PersistentDataType.STRING, type);
        it.setItemMeta(m);
        return it;
    }

    public static ItemStack camera() {
        Component name = plain(Component.text("Камера", NamedTextColor.GOLD, TextDecoration.BOLD, TextDecoration.UNDERLINED));
        List<Component> lore = List.of(
                plain(Component.text("Head ID: 9417", NamedTextColor.GRAY)),
                plain(Component.text("mcheads.ru", NamedTextColor.BLUE)));
        return head("camera", CAMERA_TEXTURE, name, lore);
    }

    public static ItemStack monitor() {
        Component name = plain(Component.text("Монитор", NamedTextColor.AQUA, TextDecoration.BOLD));
        return head("monitor", monitorTexture, name, null);
    }

    /** Тип предмета системы ("camera", "monitor", "ui") или null. */
    public static String typeOf(ItemStack it) {
        if (it == null || !it.hasItemMeta()) return null;
        return it.getItemMeta().getPersistentDataContainer().get(TYPE, PersistentDataType.STRING);
    }

    /** Кнопка интерфейса в хотбаре. */
    public static ItemStack ui(String model, Component name) {
        ItemStack it = new ItemStack(Material.PAPER);
        ItemMeta m = it.getItemMeta();
        m.setItemModel(new NamespacedKey("camsys", model));
        m.displayName(plain(name));
        m.getPersistentDataContainer().set(TYPE, PersistentDataType.STRING, "ui");
        it.setItemMeta(m);
        return it;
    }

    /** Шлем, который рисует помехи на весь экран (оверлей из ресурспака). */
    public static ItemStack overlayHelmet() {
        ItemStack it = new ItemStack(Material.PAPER);
        ItemMeta m = it.getItemMeta();
        m.displayName(plain(Component.text("Камера", NamedTextColor.GRAY)));
        EquippableComponent eq = m.getEquippable();
        eq.setSlot(EquipmentSlot.HEAD);
        eq.setCameraOverlay(new NamespacedKey("camsys", "misc/frame"));
        m.setEquippable(eq);
        m.getPersistentDataContainer().set(TYPE, PersistentDataType.STRING, "ui");
        it.setItemMeta(m);
        return it;
    }
}

package dev.camsys;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.block.BlockFace;
import org.bukkit.block.data.BlockData;
import org.bukkit.block.data.Directional;
import org.bukkit.block.data.Rotatable;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.event.Event;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockExplodeEvent;
import org.bukkit.event.block.BlockPistonExtendEvent;
import org.bukkit.event.block.BlockPistonRetractEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.EntityExplodeEvent;
import org.bukkit.event.entity.EntityPickupItemEvent;
import org.bukkit.event.entity.FoodLevelChangeEvent;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.player.PlayerCommandPreprocessEvent;
import org.bukkit.event.player.PlayerDropItemEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerItemHeldEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerSwapHandItemsEvent;
import org.bukkit.event.player.PlayerToggleFlightEvent;
import org.bukkit.event.player.PlayerToggleSneakEvent;
import org.bukkit.event.server.ServerCommandEvent;
import org.bukkit.event.world.ChunkLoadEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.util.Vector;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Base64;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

public final class CameraPlugin extends JavaPlugin implements Listener {

    static final class Session {
        UUID monitor;
        int slot;
        boolean mapMode;
        Location origin;
        GameMode gm;
        boolean allowFlight, flying, invulnerable, invisible, collidable;
        float flySpeed, walkSpeed;
        ItemStack[] inv;
    }

    private CamData data;
    private CamMap map;
    private File sessionsDir;
    private final Map<UUID, Session> sessions = new HashMap<>();
    private final Map<UUID, UUID> armed = new HashMap<>();

    public CamData data() {
        return data;
    }

    // ------------------------------------------------------------------ жизненный цикл

    @Override
    public void onEnable() {
        saveDefaultConfig();
        getDataFolder().mkdirs();
        Items.TYPE = new NamespacedKey(this, "item");
        Items.monitorTexture = getConfig().getString("monitor-texture", "");
        sessionsDir = new File(getDataFolder(), "sessions");
        sessionsDir.mkdirs();

        data = new CamData(new File(getDataFolder(), "data.yml"));
        data.load();

        String mw = getConfig().getString("map-world", "");
        World w = (mw == null || mw.isEmpty()) ? null : Bukkit.getWorld(mw);
        if (w == null) w = Bukkit.getWorlds().get(0);
        map = new CamMap(this, new File(getDataFolder(), "terrain.bin"));
        map.init(w, data.mapId);

        getServer().getPluginManager().registerEvents(this, this);
        getServer().getScheduler().runTaskTimer(this, () -> map.tick(), 1L, 1L);
        getServer().getScheduler().runTaskTimer(this, this::hud, 20L, 20L);
        getServer().getScheduler().runTaskTimer(this, this::validate, 100L, 100L);
        getServer().getScheduler().runTaskTimer(this, () -> map.save(), 6000L, 6000L);

        for (Player p : Bukkit.getOnlinePlayers()) restoreFromFile(p);
    }

    @Override
    public void onDisable() {
        for (UUID id : new ArrayList<>(sessions.keySet())) {
            Player p = Bukkit.getPlayer(id);
            if (p != null) endSession(p);
        }
        if (map != null) map.save();
        if (data != null) data.save();
    }

    // ------------------------------------------------------------------ команды

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (args.length == 0) {
            sender.sendMessage(Component.text("/camsys scan [радиус] | /camsys give <селектор> <camera|monitor>", NamedTextColor.GRAY));
            return true;
        }
        if (args[0].equalsIgnoreCase("scan")) {
            int r = 500;
            if (args.length >= 2) {
                try {
                    r = Integer.parseInt(args[1]);
                } catch (NumberFormatException ignored) {
                }
            }
            int n = map.startScan(r);
            sender.sendMessage(Component.text("Сканирование карты: в очереди " + n + " чанков (только уже существующие).", NamedTextColor.GREEN));
            return true;
        }
        if (args[0].equalsIgnoreCase("give") && args.length >= 3) {
            giveTo(sender, args[1], args[2].toLowerCase(), 1);
            return true;
        }
        sender.sendMessage(Component.text("Неизвестная подкоманда.", NamedTextColor.RED));
        return true;
    }

    /** Перехват /give <селектор> monitor|camera. */
    private boolean tryGive(CommandSender sender, String raw) {
        String line = raw.startsWith("/") ? raw.substring(1) : raw;
        String[] a = line.trim().split("\\s+");
        if (a.length < 3) return false;
        String c = a[0].toLowerCase();
        if (!c.equals("give") && !c.equals("minecraft:give")) return false;
        String item = a[2].toLowerCase();
        String type = null;
        if (item.equals("monitor") || item.equals("camsys:monitor")) type = "monitor";
        else if (item.equals("camera") || item.equals("camsys:camera")) type = "camera";
        if (type == null) return false;
        if (!sender.isOp() && !sender.hasPermission("minecraft.command.give")) return false;
        int count = 1;
        if (a.length >= 4) {
            try {
                count = Math.max(1, Math.min(64, Integer.parseInt(a[3])));
            } catch (NumberFormatException ignored) {
            }
        }
        giveTo(sender, a[1], type, count);
        return true;
    }

    private void giveTo(CommandSender sender, String selector, String type, int count) {
        List<Entity> targets;
        try {
            targets = Bukkit.selectEntities(sender, selector);
        } catch (IllegalArgumentException ex) {
            sender.sendMessage(Component.text("Неверный селектор: " + selector, NamedTextColor.RED));
            return;
        }
        int given = 0;
        for (Entity en : targets) {
            if (!(en instanceof Player p)) continue;
            ItemStack it = type.equals("monitor") ? Items.monitor() : Items.camera();
            it.setAmount(count);
            Map<Integer, ItemStack> left = p.getInventory().addItem(it);
            for (ItemStack rest : left.values()) p.getWorld().dropItemNaturally(p.getLocation(), rest);
            given++;
        }
        sender.sendMessage(Component.text("Выдано игрокам: " + given, NamedTextColor.GREEN));
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onPlayerCommand(PlayerCommandPreprocessEvent e) {
        if (tryGive(e.getPlayer(), e.getMessage())) e.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onServerCommand(ServerCommandEvent e) {
        if (tryGive(e.getSender(), e.getCommand())) e.setCancelled(true);
    }

    // ------------------------------------------------------------------ установка / ломание

    private static boolean isHead(Material m) {
        return m == Material.PLAYER_HEAD || m == Material.PLAYER_WALL_HEAD;
    }

    private static float yawOf(Block b) {
        BlockData bd = b.getBlockData();
        BlockFace f = BlockFace.SOUTH;
        if (bd instanceof Directional d) f = d.getFacing();
        else if (bd instanceof Rotatable r) f = r.getRotation();
        Vector v = f.getDirection();
        return (float) Math.toDegrees(Math.atan2(-v.getX(), v.getZ()));
    }

    @EventHandler(ignoreCancelled = true)
    public void onPlace(BlockPlaceEvent e) {
        String type = Items.typeOf(e.getItemInHand());
        if (type == null) return;
        Block b = e.getBlockPlaced();
        Player p = e.getPlayer();
        if (type.equals("monitor")) {
            CamData.Mon m = new CamData.Mon();
            m.id = UUID.randomUUID();
            m.world = b.getWorld().getName();
            m.x = b.getX();
            m.y = b.getY();
            m.z = b.getZ();
            data.monitors.put(m.id, m);
            data.save();
            p.sendActionBar(Component.text("Монитор установлен. ПКМ камерой по монитору — режим «камера ON».", NamedTextColor.GRAY));
        } else if (type.equals("camera")) {
            CamData.Cam c = new CamData.Cam();
            c.id = UUID.randomUUID();
            c.world = b.getWorld().getName();
            c.x = b.getX();
            c.y = b.getY();
            c.z = b.getZ();
            c.yaw = yawOf(b);
            data.cameras.put(c.id, c);
            UUID mon = armed.remove(p.getUniqueId());
            if (mon != null) link(p, c, mon);
            data.save();
        }
    }

    private void link(Player p, CamData.Cam c, UUID monId) {
        if (!data.monitors.containsKey(monId)) {
            p.sendActionBar(Component.text("Монитор не найден", NamedTextColor.RED));
            return;
        }
        int slot = data.freeSlot(monId);
        if (slot < 0) {
            p.sendActionBar(Component.text("К монитору уже подключено 10 камер", NamedTextColor.RED));
            return;
        }
        c.monitor = monId;
        c.slot = slot;
        p.sendActionBar(Component.text("Камера привязана к монитору (/cam " + slot + ")", NamedTextColor.GREEN));
    }

    @EventHandler(ignoreCancelled = true)
    public void onBreak(BlockBreakEvent e) {
        Block b = e.getBlock();
        CamData.Mon mon = data.monitorAt(b);
        CamData.Cam cam = data.cameraAt(b);
        ItemStack drop;
        if (mon != null) {
            data.monitors.remove(mon.id);
            for (CamData.Cam c : data.cameras.values()) {
                if (mon.id.equals(c.monitor)) {
                    c.monitor = null;
                    c.slot = 0;
                }
            }
            drop = Items.monitor();
        } else if (cam != null) {
            data.cameras.remove(cam.id);
            drop = Items.camera();
        } else {
            return;
        }
        e.setDropItems(false);
        if (e.getPlayer().getGameMode() != GameMode.CREATIVE) {
            b.getWorld().dropItemNaturally(b.getLocation().add(0.5, 0.5, 0.5), drop);
        }
        data.save();
    }

    @EventHandler(ignoreCancelled = true)
    public void onEntityExplode(EntityExplodeEvent e) {
        e.blockList().removeIf(data::isRegistered);
    }

    @EventHandler(ignoreCancelled = true)
    public void onBlockExplode(BlockExplodeEvent e) {
        e.blockList().removeIf(data::isRegistered);
    }

    @EventHandler(ignoreCancelled = true)
    public void onPistonExtend(BlockPistonExtendEvent e) {
        if (e.getBlocks().stream().anyMatch(data::isRegistered)) e.setCancelled(true);
    }

    @EventHandler(ignoreCancelled = true)
    public void onPistonRetract(BlockPistonRetractEvent e) {
        if (e.getBlocks().stream().anyMatch(data::isRegistered)) e.setCancelled(true);
    }

    /** Раз в 5 секунд убираем записи о камерах/мониторах, чьих голов уже нет. */
    private void validate() {
        boolean changed = false;
        for (CamData.Cam c : new ArrayList<>(data.cameras.values())) {
            World w = Bukkit.getWorld(c.world);
            if (w == null || !w.isChunkLoaded(c.x >> 4, c.z >> 4)) continue;
            if (!isHead(w.getBlockAt(c.x, c.y, c.z).getType())) {
                data.cameras.remove(c.id);
                changed = true;
            }
        }
        for (CamData.Mon m : new ArrayList<>(data.monitors.values())) {
            World w = Bukkit.getWorld(m.world);
            if (w == null || !w.isChunkLoaded(m.x >> 4, m.z >> 4)) continue;
            if (!isHead(w.getBlockAt(m.x, m.y, m.z).getType())) {
                data.monitors.remove(m.id);
                for (CamData.Cam c : data.cameras.values()) {
                    if (m.id.equals(c.monitor)) {
                        c.monitor = null;
                        c.slot = 0;
                    }
                }
                changed = true;
            }
        }
        if (changed) data.save();
    }

    // ------------------------------------------------------------------ клики по монитору

    @EventHandler(priority = EventPriority.HIGH)
    public void onInteract(PlayerInteractEvent e) {
        Player p = e.getPlayer();
        if (sessions.containsKey(p.getUniqueId())) {
            e.setCancelled(true);
            return;
        }
        if (e.getAction() != Action.RIGHT_CLICK_BLOCK || e.getHand() != EquipmentSlot.HAND) return;
        Block b = e.getClickedBlock();
        if (b == null || !isHead(b.getType())) return;
        CamData.Mon mon = data.monitorAt(b);
        if (mon == null) return;
        if (p.isSneaking()) return; // с Shift можно ставить блоки рядом как обычно

        e.setUseInteractedBlock(Event.Result.DENY);
        e.setUseItemInHand(Event.Result.DENY);
        e.setCancelled(true);

        if ("camera".equals(Items.typeOf(e.getItem()))) {
            armed.put(p.getUniqueId(), mon.id);
            p.sendActionBar(Component.text("Камера ON — поставьте камеру на блок", NamedTextColor.GREEN));
            return;
        }
        startSession(p, mon);
    }

    // ------------------------------------------------------------------ просмотр камер

    private ItemStack labelItem(Session s) {
        return Items.ui("blank", Component.text("/cam " + s.slot, NamedTextColor.RED));
    }

    private void buildHotbar(Player p, Session s) {
        var inv = p.getInventory();
        inv.clear();
        inv.setHelmet(Items.overlayHelmet());
        inv.setItem(0, Items.ui("map_btn", Component.text("Карта", NamedTextColor.GOLD)));
        inv.setItem(3, Items.ui("arrow_left", Component.text("Предыдущая камера", NamedTextColor.WHITE)));
        inv.setItem(4, s.mapMode ? map.mapItem() : labelItem(s));
        inv.setItem(5, Items.ui("arrow_right", Component.text("Следующая камера", NamedTextColor.WHITE)));
        inv.setItem(8, Items.ui("exit_btn", Component.text("Выйти", NamedTextColor.RED)));
        inv.setHeldItemSlot(4);
    }

    private void goTo(Player p, CamData.Cam c) {
        World w = Bukkit.getWorld(c.world);
        if (w == null) return;
        double dx = -Math.sin(Math.toRadians(c.yaw));
        double dz = Math.cos(Math.toRadians(c.yaw));
        // глаза игрока (1.62 от ног) - в центре головы, чуть вперёд
        Location feet = new Location(w, c.x + 0.5 + dx * 0.35, c.y + 0.4 - 1.62, c.z + 0.5 + dz * 0.35, c.yaw, 0f);
        p.teleport(feet);
    }

    private void startSession(Player p, CamData.Mon mon) {
        if (sessions.containsKey(p.getUniqueId())) return;
        List<CamData.Cam> cams = data.camsOf(mon.id);
        if (cams.isEmpty()) {
            p.sendActionBar(Component.text("К монитору не подключено ни одной камеры", NamedTextColor.RED));
            return;
        }
        p.leaveVehicle();

        Session s = new Session();
        s.monitor = mon.id;
        s.slot = cams.get(0).slot;
        s.origin = p.getLocation().clone();
        s.gm = p.getGameMode();
        s.allowFlight = p.getAllowFlight();
        s.flying = p.isFlying();
        s.flySpeed = p.getFlySpeed();
        s.walkSpeed = p.getWalkSpeed();
        s.invulnerable = p.isInvulnerable();
        s.invisible = p.isInvisible();
        s.collidable = p.isCollidable();
        s.inv = p.getInventory().getContents().clone();
        writeSession(p.getUniqueId(), s);
        sessions.put(p.getUniqueId(), s);

        p.setGameMode(GameMode.ADVENTURE);
        p.setAllowFlight(true);
        p.setFlying(true);
        p.setFlySpeed(0f);
        p.setWalkSpeed(0f);
        p.setInvulnerable(true);
        p.setInvisible(true);
        p.setCollidable(false);

        buildHotbar(p, s);
        goTo(p, cams.get(0));
        p.sendMessage(Component.text("Камера: колесо мыши или клавиши 4 / 6 — листать, 1 — карта, 9 или Shift — выход", NamedTextColor.GRAY));
        p.sendActionBar(Component.text("/cam " + s.slot, NamedTextColor.RED));
    }

    private void switchCam(Player p, Session s, int dir) {
        List<CamData.Cam> cams = data.camsOf(s.monitor);
        if (cams.isEmpty()) {
            endSession(p);
            return;
        }
        int idx = 0;
        for (int i = 0; i < cams.size(); i++) {
            if (cams.get(i).slot == s.slot) idx = i;
        }
        idx = Math.floorMod(idx + dir, cams.size());
        CamData.Cam c = cams.get(idx);
        s.slot = c.slot;
        goTo(p, c);
        if (!s.mapMode) p.getInventory().setItem(4, labelItem(s));
        p.sendActionBar(Component.text("/cam " + s.slot, NamedTextColor.RED));
    }

    private void toggleMap(Player p, Session s) {
        s.mapMode = !s.mapMode;
        p.getInventory().setItem(4, s.mapMode ? map.mapItem() : labelItem(s));
        if (!s.mapMode) p.sendActionBar(Component.text("/cam " + s.slot, NamedTextColor.RED));
    }

    /** Точки камер для карты: {x, z в единицах курсора, 1 если это текущая камера}. */
    public List<int[]> cursorsFor(Player p) {
        Session s = sessions.get(p.getUniqueId());
        List<int[]> out = new ArrayList<>();
        if (s == null) return out;
        for (CamData.Cam c : data.camsOf(s.monitor)) {
            if (!c.world.equals(map.world().getName())) continue;
            int cx = Math.max(-128, Math.min(127, Math.round(c.x / 4f)));
            int cz = Math.max(-128, Math.min(127, Math.round(c.z / 4f)));
            out.add(new int[]{cx, cz, c.slot == s.slot ? 1 : 0});
        }
        return out;
    }

    private void hud() {
        for (Map.Entry<UUID, Session> en : sessions.entrySet()) {
            Player p = Bukkit.getPlayer(en.getKey());
            if (p == null || en.getValue().mapMode) continue;
            p.sendActionBar(Component.text("/cam " + en.getValue().slot, NamedTextColor.RED));
        }
    }

    // ------------------------------------------------------------------ выход и восстановление

    private void restoreProps(Player p, Session s) {
        p.setInvulnerable(s.invulnerable);
        p.setInvisible(s.invisible);
        p.setCollidable(s.collidable);
        p.setFlySpeed(s.flySpeed);
        p.setWalkSpeed(s.walkSpeed);
        p.setGameMode(s.gm);
        p.setAllowFlight(s.allowFlight);
        p.setFlying(s.flying && s.allowFlight);
    }

    private void applyRestore(Player p, Session s, boolean teleport) {
        restoreProps(p, s);
        p.getInventory().clear();
        if (s.inv != null) p.getInventory().setContents(s.inv);
        if (teleport && s.origin != null && s.origin.getWorld() != null) p.teleport(s.origin);
        p.sendActionBar(Component.empty());
    }

    private void endSession(Player p) {
        Session s = sessions.remove(p.getUniqueId());
        if (s == null) return;
        armed.remove(p.getUniqueId());
        applyRestore(p, s, true);
        deleteSessionFile(p.getUniqueId());
    }

    private void restoreFromFile(Player p) {
        File f = new File(sessionsDir, p.getUniqueId() + ".yml");
        if (!f.exists() || sessions.containsKey(p.getUniqueId())) return;
        Session s = readSession(f);
        if (s != null) applyRestore(p, s, true);
        f.delete();
    }

    private void deleteSessionFile(UUID id) {
        File f = new File(sessionsDir, id + ".yml");
        if (f.exists()) f.delete();
    }

    private void writeSession(UUID id, Session s) {
        YamlConfiguration y = new YamlConfiguration();
        Location o = s.origin;
        y.set("world", o.getWorld().getName());
        y.set("x", o.getX());
        y.set("y", o.getY());
        y.set("z", o.getZ());
        y.set("yaw", (double) o.getYaw());
        y.set("pitch", (double) o.getPitch());
        y.set("gm", s.gm.name());
        y.set("allowFlight", s.allowFlight);
        y.set("flying", s.flying);
        y.set("invulnerable", s.invulnerable);
        y.set("invisible", s.invisible);
        y.set("collidable", s.collidable);
        y.set("flySpeed", (double) s.flySpeed);
        y.set("walkSpeed", (double) s.walkSpeed);
        ItemStack[] safe = new ItemStack[s.inv.length];
        for (int i = 0; i < safe.length; i++) {
            safe[i] = s.inv[i] == null ? new ItemStack(Material.AIR) : s.inv[i];
        }
        y.set("inv", Base64.getEncoder().encodeToString(ItemStack.serializeItemsAsBytes(safe)));
        try {
            y.save(new File(sessionsDir, id + ".yml"));
        } catch (IOException ex) {
            ex.printStackTrace();
        }
    }

    private Session readSession(File f) {
        try {
            YamlConfiguration y = YamlConfiguration.loadConfiguration(f);
            Session s = new Session();
            World w = Bukkit.getWorld(y.getString("world", ""));
            if (w == null) w = Bukkit.getWorlds().get(0);
            s.origin = new Location(w, y.getDouble("x"), y.getDouble("y"), y.getDouble("z"),
                    (float) y.getDouble("yaw"), (float) y.getDouble("pitch"));
            s.gm = GameMode.valueOf(y.getString("gm", "SURVIVAL"));
            s.allowFlight = y.getBoolean("allowFlight");
            s.flying = y.getBoolean("flying");
            s.invulnerable = y.getBoolean("invulnerable");
            s.invisible = y.getBoolean("invisible");
            s.collidable = y.getBoolean("collidable", true);
            s.flySpeed = (float) y.getDouble("flySpeed", 0.1);
            s.walkSpeed = (float) y.getDouble("walkSpeed", 0.2);
            String inv = y.getString("inv", "");
            if (inv != null && !inv.isEmpty()) {
                s.inv = ItemStack.deserializeItemsFromBytes(Base64.getDecoder().decode(inv));
            }
            return s;
        } catch (Exception ex) {
            ex.printStackTrace();
            return null;
        }
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent e) {
        restoreFromFile(e.getPlayer());
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        endSession(e.getPlayer());
        armed.remove(e.getPlayer().getUniqueId());
    }

    @EventHandler
    public void onDeath(PlayerDeathEvent e) {
        Player p = e.getEntity();
        Session s = sessions.remove(p.getUniqueId());
        if (s == null) return;
        restoreProps(p, s);
        deleteSessionFile(p.getUniqueId());
        if (e.getKeepInventory()) {
            e.getDrops().clear();
            p.getInventory().clear();
            if (s.inv != null) p.getInventory().setContents(s.inv);
        } else {
            e.getDrops().clear();
            if (s.inv != null) {
                for (ItemStack it : s.inv) {
                    if (it != null && !it.getType().isAir()) e.getDrops().add(it);
                }
            }
        }
    }

    // ------------------------------------------------------------------ управление и защита во время просмотра

    private boolean in(Player p) {
        return sessions.containsKey(p.getUniqueId());
    }

    @EventHandler
    public void onHeld(PlayerItemHeldEvent e) {
        Player p = e.getPlayer();
        Session s = sessions.get(p.getUniqueId());
        if (s == null) return;
        e.setCancelled(true);
        switch (e.getNewSlot()) {
            case 0 -> toggleMap(p, s);
            case 3 -> switchCam(p, s, -1);
            case 5 -> switchCam(p, s, 1);
            case 8 -> endSession(p);
            default -> {
            }
        }
    }

    @EventHandler
    public void onSneak(PlayerToggleSneakEvent e) {
        if (e.isSneaking() && in(e.getPlayer())) endSession(e.getPlayer());
    }

    @EventHandler
    public void onMove(PlayerMoveEvent e) {
        if (!in(e.getPlayer())) return;
        Location f = e.getFrom();
        Location t = e.getTo();
        if (t == null) return;
        if (t.getX() != f.getX() || t.getY() != f.getY() || t.getZ() != f.getZ()) {
            Location back = f.clone();
            back.setYaw(t.getYaw());
            back.setPitch(t.getPitch());
            e.setTo(back);
        }
    }

    @EventHandler
    public void onFlight(PlayerToggleFlightEvent e) {
        if (in(e.getPlayer())) e.setCancelled(true);
    }

    @EventHandler
    public void onPlaceDuring(BlockPlaceEvent e) {
        if (in(e.getPlayer())) e.setCancelled(true);
    }

    @EventHandler
    public void onBreakDuring(BlockBreakEvent e) {
        if (in(e.getPlayer())) e.setCancelled(true);
    }

    @EventHandler
    public void onDrop(PlayerDropItemEvent e) {
        if (in(e.getPlayer())) e.setCancelled(true);
    }

    @EventHandler
    public void onSwap(PlayerSwapHandItemsEvent e) {
        if (in(e.getPlayer())) e.setCancelled(true);
    }

    @EventHandler
    public void onClick(InventoryClickEvent e) {
        if (e.getWhoClicked() instanceof Player p && in(p)) e.setCancelled(true);
    }

    @EventHandler
    public void onDrag(InventoryDragEvent e) {
        if (e.getWhoClicked() instanceof Player p && in(p)) e.setCancelled(true);
    }

    @EventHandler
    public void onPickup(EntityPickupItemEvent e) {
        if (e.getEntity() instanceof Player p && in(p)) e.setCancelled(true);
    }

    @EventHandler
    public void onDamage(EntityDamageEvent e) {
        if (e.getEntity() instanceof Player p && in(p)) e.setCancelled(true);
    }

    @EventHandler
    public void onFood(FoodLevelChangeEvent e) {
        if (e.getEntity() instanceof Player p && in(p)) e.setCancelled(true);
    }

    // ------------------------------------------------------------------ карта

    @EventHandler
    public void onChunkLoad(ChunkLoadEvent e) {
        if (map != null && e.getWorld().equals(map.world())) {
            map.queueChunk(e.getChunk().getX(), e.getChunk().getZ());
        }
    }
}

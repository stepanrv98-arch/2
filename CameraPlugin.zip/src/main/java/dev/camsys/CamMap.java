package dev.camsys;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.Bukkit;
import org.bukkit.Chunk;
import org.bukkit.Color;
import org.bukkit.HeightMap;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.MapMeta;
import org.bukkit.map.MapCanvas;
import org.bukkit.map.MapCursor;
import org.bukkit.map.MapCursorCollection;
import org.bukkit.map.MapPalette;
import org.bukkit.map.MapRenderer;
import org.bukkit.map.MapView;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * Карта мира 1000x1000 (центр 0,0) в духе Xaero's World Map: рисуется сверху по загруженным/посещённым
 * чанкам, неисследованное - тёмное. Камеры монитора показываются точками.
 */
public final class CamMap {

    static final int SIZE = 1024;
    static final int HALF = 512;

    private final CameraPlugin plugin;
    private final File file;
    private final byte[] terrain = new byte[SIZE * SIZE];
    private final ArrayDeque<int[]> sampleQueue = new ArrayDeque<>();
    private final ArrayDeque<int[]> scanQueue = new ArrayDeque<>();
    private final Map<Integer, Byte> colorCache = new HashMap<>();

    private World world;
    private MapView view;
    private byte unexplored;
    private int version = 1;
    private boolean changed;
    private boolean dirtyDisk;
    private int sinceBump;

    public CamMap(CameraPlugin plugin, File file) {
        this.plugin = plugin;
        this.file = file;
    }

    @SuppressWarnings("deprecation")
    public void init(World w, int savedMapId) {
        this.world = w;
        this.unexplored = MapPalette.matchColor(22, 22, 28);
        if (file.exists()) {
            try {
                byte[] b = Files.readAllBytes(file.toPath());
                if (b.length == terrain.length) System.arraycopy(b, 0, terrain, 0, b.length);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        MapView v = savedMapId >= 0 ? Bukkit.getMap(savedMapId) : null;
        if (v == null) {
            v = Bukkit.createMap(w);
            plugin.data().mapId = v.getId();
            plugin.data().save();
        }
        v.setScale(MapView.Scale.FAR);
        v.setCenterX(0);
        v.setCenterZ(0);
        v.setTrackingPosition(false);
        v.setUnlimitedTracking(false);
        for (MapRenderer r : new ArrayList<>(v.getRenderers())) v.removeRenderer(r);
        v.addRenderer(new Renderer());
        this.view = v;
    }

    public World world() {
        return world;
    }

    public void queueChunk(int cx, int cz) {
        sampleQueue.add(new int[]{cx, cz});
    }

    /** Поставить в очередь сканирование уже существующих чанков в радиусе (в блоках). */
    public int startScan(int radius) {
        int r = Math.min(radius, HALF) >> 4;
        int n = 0;
        for (int cx = -r - 1; cx <= r; cx++) {
            for (int cz = -r - 1; cz <= r; cz++) {
                scanQueue.add(new int[]{cx, cz});
                n++;
            }
        }
        return n;
    }

    public int scanRemaining() {
        return scanQueue.size();
    }

    /** Вызывается каждый тик. */
    public void tick() {
        if (world == null) return;
        int budget = 4;
        while (budget-- > 0 && !sampleQueue.isEmpty()) {
            int[] c = sampleQueue.poll();
            if (world.isChunkLoaded(c[0], c[1])) sample(world.getChunkAt(c[0], c[1]));
        }
        int sb = 3;
        while (sb-- > 0 && !scanQueue.isEmpty()) {
            int[] c = scanQueue.poll();
            world.getChunkAtAsync(c[0], c[1], false).thenAccept(ch -> {
                if (ch != null) sample(ch);
            });
        }
        sinceBump++;
        if (changed && sinceBump >= 20) {
            version++;
            changed = false;
            sinceBump = 0;
        }
    }

    public void save() {
        if (!dirtyDisk) return;
        try {
            Files.write(file.toPath(), terrain);
            dirtyDisk = false;
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @SuppressWarnings("deprecation")
    private byte colorIndex(Color c, int mult) {
        int key = (c.getRed() << 16 | c.getGreen() << 8 | c.getBlue()) * 31 + mult;
        Byte cached = colorCache.get(key);
        if (cached != null) return cached;
        int r = Math.min(255, c.getRed() * mult / 255);
        int g = Math.min(255, c.getGreen() * mult / 255);
        int b = Math.min(255, c.getBlue() * mult / 255);
        byte idx = MapPalette.matchColor(r, g, b);
        colorCache.put(key, idx);
        return idx;
    }

    private void sample(Chunk c) {
        World w = c.getWorld();
        if (!w.equals(world)) return;
        int bx = c.getX() << 4;
        int bz = c.getZ() << 4;
        int[] prev = new int[16];
        java.util.Arrays.fill(prev, Integer.MIN_VALUE);
        boolean any = false;
        for (int lz = 0; lz < 16; lz++) {
            for (int lx = 0; lx < 16; lx++) {
                int wx = bx + lx;
                int wz = bz + lz;
                int y = w.getHighestBlockYAt(wx, wz, HeightMap.WORLD_SURFACE);
                Block b = c.getBlock(lx, y, lz);
                Material m = b.getType();
                if (m.isAir()) {
                    prev[lx] = y;
                    continue;
                }
                if (wx < -HALF || wx >= HALF || wz < -HALF || wz >= HALF) {
                    prev[lx] = y;
                    continue;
                }
                Color col = b.getBlockData().getMapColor();
                int mult = 220;
                int p = prev[lx];
                if (p != Integer.MIN_VALUE) {
                    if (y > p) mult = 255;
                    else if (y < p) mult = (y < p - 2) ? 135 : 180;
                }
                prev[lx] = y;
                if (col == null) continue;
                byte idx = colorIndex(col, mult);
                if (idx == 0) idx = unexplored;
                terrain[(wx + HALF) + (wz + HALF) * SIZE] = idx;
                any = true;
            }
        }
        if (any) {
            changed = true;
            dirtyDisk = true;
        }
    }

    public ItemStack mapItem() {
        ItemStack it = new ItemStack(Material.FILLED_MAP);
        MapMeta mm = (MapMeta) it.getItemMeta();
        mm.setMapView(view);
        mm.displayName(Component.text("Карта", NamedTextColor.GOLD).decoration(TextDecoration.ITALIC, false));
        it.setItemMeta(mm);
        return it;
    }

    private byte pixel(int mx, int mz) {
        int[][] offs = {{4, 4}, {1, 1}, {7, 7}, {1, 7}, {7, 1}};
        for (int[] o : offs) {
            byte v = terrain[(mx * 8 + o[0]) + (mz * 8 + o[1]) * SIZE];
            if (v != 0) return v;
        }
        return unexplored;
    }

    private final class Renderer extends MapRenderer {
        private final Map<UUID, Integer> drawn = new HashMap<>();

        Renderer() {
            super(true);
        }

        @SuppressWarnings("deprecation")
        @Override
        public void render(MapView mv, MapCanvas canvas, Player player) {
            Integer v = drawn.get(player.getUniqueId());
            if (v == null || v != version) {
                for (int mz = 0; mz < 128; mz++) {
                    for (int mx = 0; mx < 128; mx++) {
                        canvas.setPixel(mx, mz, pixel(mx, mz));
                    }
                }
                drawn.put(player.getUniqueId(), version);
            }
            MapCursorCollection cc = canvas.getCursors();
            while (cc.size() > 0) cc.removeCursor(cc.getCursor(0));
            for (int[] c : plugin.cursorsFor(player)) {
                MapCursor.Type type = c[2] == 1 ? MapCursor.Type.BLUE_MARKER : MapCursor.Type.RED_MARKER;
                cc.addCursor(new MapCursor((byte) c[0], (byte) c[1], (byte) 8, type, true));
            }
        }
    }
}
